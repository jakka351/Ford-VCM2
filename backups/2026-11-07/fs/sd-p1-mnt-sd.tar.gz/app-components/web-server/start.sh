#! /bin/bash

WEB_SERVER_DIR=/mnt/sd/app-components/web-server
if [ "$(pidof lighttpd)" ]
then
	echo "Web-server already running...."
else
	echo "Starting Web-server....."
	$WEB_SERVER_DIR/bin/lighttpd -f $WEB_SERVER_DIR/lighttpd.conf
fi 
