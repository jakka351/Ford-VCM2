#! /bin/bash

WEB_SERVER_DIR=/mnt/sd/app-components/web-server
