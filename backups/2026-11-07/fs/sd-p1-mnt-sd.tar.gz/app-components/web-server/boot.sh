#! /bin/bash

# WEB_SERVER_DIR=/mnt/sd/app-components/web-server
# APPS_DIR=/usr/local/apps
 
#Adding web-server library to ldconf
# echo $WEB_SERVER_DIR/lib >> /etc/ld.so.conf
# ldconfig > /dev/null 2>&1

#get the base conf file
# cp -f $WEB_SERVER_DIR/lighttpd-main.conf $WEB_SERVER_DIR/lighttpd.conf
 
#collect conf file addons for all apps
# declare -a conffiles
# conffiles=(`find $APPS_DIR -name 'lighttpd-addon.conf'`)

# cnt=${#conffiles[@]}

# for (( i = 0 ; i < cnt ; i++ ))
# do
  	# echo "Web-server. Merging conf file: ${conffiles[$i]}"
	# echo "include \"${conffiles[$i]}\"" >> $WEB_SERVER_DIR/lighttpd.conf
# done

# sync;sync;sync;
