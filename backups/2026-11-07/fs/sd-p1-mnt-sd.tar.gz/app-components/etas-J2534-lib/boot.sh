#! /bin/bash
ETAS_J2534_LIB_DIR=/mnt/sd/app-components/etas-J2534-lib

# Adding etas-J2534-lib library to ldconf
if [ ! -e /etc/vci/config/j2534_log_enable ]
then
	echo $ETAS_J2534_LIB_DIR >> /etc/ld.so.conf
fi
