#! /bin/bash

ETAS_J2534_LIB_MON_DIR=/mnt/sd/app-components/etas-J2534-mon-lib

if [ -e /etc/vci/config/j2534_log_enable ]
then
	echo J2534 Logging Enabled

	# Adding etas-J2534-lib library to ldconf
	echo $ETAS_J2534_LIB_MON_DIR >> /etc/ld.so.conf
	ldconfig > /dev/null 2>&1
	cd $ETAS_J2534_LIB_MON_DIR
	ln -s -f libbvtx4j32.so.? libbvtx4j32.so
	ldconfig > /dev/null 2>&1
fi
