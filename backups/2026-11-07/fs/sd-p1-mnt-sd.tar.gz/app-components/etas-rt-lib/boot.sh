#! /bin/bash
ETAS_RT_LIB_DIR=/mnt/sd/app-components/etas-rt-lib

# Adding etas-rt-lib library to ldconf
echo $ETAS_RT_LIB_DIR >> /etc/ld.so.conf
