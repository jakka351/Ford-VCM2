#! /bin/bash
ETAS_VCI_LIB_DIR=/mnt/sd/app-components/etas-vci-lib

if [ ! -e /etc/vci/config/pdu_log_enable ]
then
	echo $ETAS_VCI_LIB_DIR >> /etc/ld.so.conf
fi
