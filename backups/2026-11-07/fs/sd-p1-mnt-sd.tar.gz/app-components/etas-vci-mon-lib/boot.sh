#! /bin/bash
ETAS_VCI_LIB_MON_DIR=/mnt/sd/app-components/etas-vci-mon-lib

if [ -e /etc/vci/config/pdu_log_enable ]
then
	echo PDU Logging Enabled

	# Adding etas-pdu-lib library to ldconf
	echo $ETAS_VCI_LIB_MON_DIR >> /etc/ld.so.conf
	ldconfig > /dev/null 2>&1
	cd $ETAS_VCI_LIB_MON_DIR
	ln -s -f libbvtx-vci-pdu.so.? libbvtx-vci-pdu.so
	ldconfig > /dev/null 2>&1

fi