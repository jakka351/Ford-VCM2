#! /bin/bash
echo stopping Pendant Reprogramming Process
