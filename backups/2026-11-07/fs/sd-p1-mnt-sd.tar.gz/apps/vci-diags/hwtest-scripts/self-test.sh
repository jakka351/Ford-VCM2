#! /bin/bash
#
#

cd /etc/vci/config/diagnostics/hwtest-scripts
/etc/vci/config/diagnostics/hwtest-scripts/hwcheckout_ST.6516_FD -l 1 -C 1 > /tmp/results

