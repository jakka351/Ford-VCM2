
//#include "led.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <sys/time.h>
#include <stdarg.h>
#include <signal.h>
#include <string.h>


////////////////////////////////////////
#include <fcntl.h>
#include <sys/ioctl.h> 

#define LED_IOC_MAGIC 'E'
#define LED_IOCTL_VERSION_SEQ	1
#define LED_IOCTL_VERSION_SIZE	stVersionInfo
#define LED_IOCTL_PERSISTENT	2

#define LED_IOC_VERSION _IOR(LED_IOC_MAGIC, LED_IOCTL_VERSION_SEQ, LED_IOCTL_VERSION_SIZE)
#define LED_IOC_PERSIST _IO(LED_IOC_MAGIC, LED_IOCTL_PERSISTENT)

#define LED_ACTIVITY_FREQUENCY 10       /* Hertz */

#define LED_OFF 0
#define LED_ON 1
#define LED_BLINK 2

#define LED_MIN_FREQ 1
#define LED_MAX_FREQ 1000

#define LED_MIN_DUTY 1
#define LED_MAX_DUTY 1000
#define LED_1 0
#define LED_2 1
#define LED_3 2
#define LED_4 3
#define LED_5 4
//#define MAX_NUM_LEDS 5
#define MAX_NUM_LEDS 11

#define POWER_LED LED_1
#define PC_ACTIVITY_LED LED_2
#define ERROR_LED LED_3
#define VEHICLE_ACTIVITY_LED LED_4
#define STATUS_LED LED_5

enum VCI_LED_IDS {
    VCI_LED_1 = 1, /* Power */
    VCI_LED_2, /* PC Connectivity */
    VCI_LED_3, /* Error */
    VCI_LED_4, /* Vehicle Connectivity */
    VCI_LED_5, /* Check Mark */
    VCI_LED_6, /* Trigger LED 1*/
    VCI_LED_7, /* Trigger LED 2 */
};
enum VCI_LED_CONTROL {
        VCI_LED_OFF = 0,
        VCI_LED_ON,
	VCI_LED_RELINQUISH_CONTROL, // Value not returned for VCIGetLED()
};


typedef struct {
        unsigned int uiLED_1;
        unsigned int uiLED_2;
        unsigned int uiLED_3;
        unsigned int uiLED_4;
        unsigned int uiLED_5;
        unsigned int uiLED_6;
        unsigned int uiLED_7;
} stReadLED;

typedef struct {
        unsigned int uiVersion;
        unsigned int uiDate;
}stVersionInfo;

typedef struct {
	unsigned int led;
	unsigned int led_state;
	unsigned int led_frequency;     /* Hertz 1 - ??? */
} led_cmd_t;

int drv_fd;

/***********************************************
 *
 *
 *
 *
 * ********************************************/

void usage()
{

	printf("\nUsage:\n	setled  0 0 1 0 0   or setled 3  -- turns on led3\n");
	printf("	setleds: 0  -- turns all LEDs off\n");
}

int set_leds(led_cmd_t *led, unsigned int num_leds)
{
	int sizeTowrite, sizeWritten;
int i;

	if (num_leds > MAX_NUM_LEDS || num_leds <= 0) {
		printf("setleds: set_leds(): num_leds (%d) out of range\n", num_leds);
		return(-1);
	}

	sizeTowrite = sizeof(led_cmd_t) * num_leds;

	//printf("set_leds writing: ");
	//for (i=0; i<num_leds;i++) {
	//  printf("led %d state %d : ", led[i].led, led[i].led_state);
	//}
	//printf("\n");

	sizeWritten = write(drv_fd, led, sizeTowrite);
	if (sizeWritten != sizeTowrite) {
		printf("setleds: set_leds(): write failed\n");
		return(-1);
	}

	return 0;
}


int main(int argc, char *argv[])
{
	stVersionInfo VersionInfo;
	led_cmd_t LEDs[MAX_NUM_LEDS];
	int nread;


        /* Open the driver and read the driver verion information */
        drv_fd = open("/dev/etas-led", O_RDWR);

        if (drv_fd  < 0 ) {
		printf("error Failed to open LED driver\n");
		exit(1);
	}

	// otherwise etas-led turns all OFF when driver is closed
	if (ioctl(drv_fd, LED_IOC_PERSIST) != 0) {
		printf("failed to set IOC_PERSIST\n");
		exit(1);
	}

	memset(LEDs, 0, sizeof(LEDs));

	nread = read (drv_fd, LEDs, sizeof(LEDs));
	if (nread != sizeof(LEDs)) {
		printf("bad read\n");
		perror("setleds");
		exit(1);
	}

	//printf("setleds: current state: %d %d %d %d %d\n",
	//	LEDs[0].led_state,LEDs[1].led_state,LEDs[2].led_state,LEDs[3].led_state,LEDs[4].led_state);
   
	if(argc == 6) {
		LEDs[0].led = POWER_LED;
		LEDs[0].led_state = atoi( argv[1] ) ? LED_ON : LED_OFF;   
	
		LEDs[1].led = PC_ACTIVITY_LED;
		LEDs[1].led_state = atoi( argv[2] ) ? LED_ON : LED_OFF;   
		
		LEDs[2].led = ERROR_LED;
		LEDs[2].led_state = atoi( argv[3] ) ? LED_ON : LED_OFF;   
		
		LEDs[3].led = VEHICLE_ACTIVITY_LED;
		LEDs[3].led_state = atoi( argv[4] ) ? LED_ON : LED_OFF;   
		
		LEDs[4].led = STATUS_LED;
		LEDs[4].led_state = atoi( argv[5] ) ? LED_ON : LED_OFF;   

		set_leds(LEDs, MAX_NUM_LEDS);
	}

	// Single argument:  0: turn all off, else turn on that number
	if(argc == 2) {
		led_cmd_t led_cmd;
		int led = atoi( argv[1] );   

		memset (&led_cmd, 0, sizeof(led_cmd_t));
		switch (led) {
			case 0: 
				LEDs[0].led = POWER_LED;
				LEDs[0].led_state =  LED_OFF;   
			
				LEDs[1].led = PC_ACTIVITY_LED;
				LEDs[1].led_state =  LED_OFF;   
		
				LEDs[2].led = ERROR_LED;
				LEDs[2].led_state =  LED_OFF;   
		
				LEDs[3].led = VEHICLE_ACTIVITY_LED;
				LEDs[3].led_state =  LED_OFF;   
		
				LEDs[4].led = STATUS_LED;
				LEDs[4].led_state =  LED_OFF;   

				set_leds(LEDs, MAX_NUM_LEDS);
				break;
			case 5:
			case 4:
			case 3:
			case 2:
			case 1:
				led_cmd.led = led - 1;
				led_cmd.led_state = LED_ON;   
				set_leds(&led_cmd, 1);
				break;

			default:
				usage();
				exit(1);
		}
	}
  


	if( argc != 2 && argc != 6)
	{
		int iRead = ioctl(drv_fd, LED_IOC_VERSION, &VersionInfo);
		if (iRead == sizeof(stVersionInfo)) {
			printf("LED Driver Version %X - %X\n",VersionInfo.uiVersion, VersionInfo.uiDate );
		} else {
			perror("setled");
			printf("Can't get LED driver version info.\n");
			exit(1);
		}
		usage();
	}

	//close(drv_fd);

	return 0;
}

