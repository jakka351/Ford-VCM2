#!/bin/bash

enable -f /etc/vci/config/diagnostics/hwtest-scripts/memdump.so mem dump

count=1
LEDs_or_beeper_fail=FALSE

##############INSERT VCItype DETECTION###############

VCItype="STD"
export VCItype
#####################################################


function wait_power_button {
	PASS=0
	FAIL=1
	button_return=$FAIL

	while [ $button_return = $FAIL ]
	do
		raw=`dump -b 0x40e00000 -l 4 -4`
		val=`echo $raw | sed 's/0x.*: /0x/'`
		if [ $(($val & 1)) -eq 1 ]; then
			./setled 1 0 0 0 0
			usleep 300000
			./setled 0 0 0 0 1
			usleep 300000
		else
			./setled 1 1 0 1 1
			usleep 500000
			button_return=$PASS
		fi
	done
}

# Check for USB memory stick
#	Look for usb-exec.sh
#	If found, execute script and exit from burnin.sh.
#
grep sda1 /proc/mounts > /dev/null
if [ $? -eq 0 ]; then
	if [ -e /mnt/usb-exec.sh ]; then
		/mnt/usb-exec.sh
		exit
	fi
	echo "USB stick found, but no usb-exec.sh script."
	sleep 1
	exit
fi

cd /etc/vci/config/diagnostics/hwtest-scripts

killall -q flashLEDs
killall -q startcount
killall -q poll_power_button
killall -q power_button_timeout
killall -q powermod
killall -q counttime
rm -f /tmp/external-failures

if [ $VCItype != "STD" -a $VCItype != "STD-E" -a $VCItype != "6516-E" ]; then
	mkdir -p /etc/vci/config/diagnostics/results
	echo "Boot"  >> ../results/burnin-time
	./counttime &
	./loopback_present 
else
	# VCI-STD: no SD card, save results in flash filesystem
	#echo VCI-STD diagnostics
	echo VCI-6516 diagnostics
	mkdir -p /etc/vci/config/diagnostics/results
# No need for a link as the old config/diags and apps/diags are now the same place
#	if [ ! -e /etc/vci/config/diagnostics/results ]; then
#		ln -s /usr/local/config/diags/results /usr/local/apps/diags/results
#	fi
	if [ ! -e /etc/vci/config/diagnostics/hwtest-scripts/seq_file ]; then
		cp /etc/vci/config/diagnostics/hwtest-scripts/seq_file.initial /etc/vci/config/diagnostics/hwtest-scripts/seq_file
	fi
	#ln -s /etc/vci/config/diagnostics/seq_file /etc/vci/config/diagnostics/hwtest-scripts/seq_file
	if [ ! -e /etc/vci/config/diagnostics/hwtest-scripts/startcount ]; then
		cp /etc/vci/config/diagnostics/hwtest-scripts/startcount.initial /etc/vci/config/diagnostics/hwtest-scripts/startcount
	fi
	
	echo "Boot"  >> ../results/burnin-time
	./counttime &
	./loopback_present.6516 
fi
#
# NO INSERTIONS between loopback_present and this "if"
#
if [ $? != 0 ]; then
echo Waiting for power-button
echo Waiting for power-button > /tmp/waiting

	echo "Loopback connector not present."  >> ../results/burnin-time
	echo "    Waiting for power-button press to run non-loopback burnin test..."  >> ../results/burnin-time
	wait_power_button
	sleep 1
	# This open-ended non-loopback test can be cleanly terminated
	# by pressing the power button until all the green LEDs flash once.
	./poll_power_button &
	# put httpd to sleep
	#killall -STOP httpd
	# turn radio off to reduce current fluctuations during burnin
	#/usr/sbin/iwpriv eth1 radiooff
	./hwcheckout -b
	echo "Burn-in done"
	echo "Burn-in done"  >> ../results/burnin-time
else
	rm -f /etc/vci/config/diagnostics/results/*{FAIL,PASS}
	
	# Required so interface will show RUNNING when cable is inserted.
	#	(moved this to /etc/rcS for diagnostic load)
	ifconfig usb0 | grep RUNNING > /dev/null
	if [ $? != 0 ]; then
		echo "Running Long term Burn-in"
		echo "Burn-in"  >> ../results/burnin-time
		# Optional:  momentary press of power button can end burnin early.
		./poll_power_button &
		./startcount &
		# put httpd to sleep
		#killall -STOP httpd
		# turn radio off to reduce current fluctuations during burnin
		#/usr/sbin/iwpriv eth1 radiooff
		./hwcheckout -b
		echo "Burn-in done"  >> ../results/burnin-time
	else
		echo "Starting LEDs test..."
		echo "LEDs test..." >> ../results/burnin-time
		./power_button_timeout &
		if [ $VCItype != "STD" -a $VCItype != "STD-E" -a $VCItype != "6516" ]; then
			./Power_button_LEDs_beeper.txt LEDs_only
		else
			./User-Interface-Test.STD
		fi
		if [ $? != 0 ]; then
			echo "LEDs/Power-button test either failed or timed-out." >> ../results/LEDs.FAIL
			echo "LEDs/Power-button test either failed or timed-out." >> ../results/burnin-time
			LEDs_or_beeper_fail=TRUE
		else
			echo "LEDs/Power-button test passed." >> ../results/LEDs.PASS
			echo "LEDs/Power-button test passed." >> ../results/burnin-time
		fi
		
		killall -q power_button_timeout >& /dev/null
		sleep 1
		echo "Starting Beeper test..."
		echo "Beeper test..." >> ../results/burnin-time
		./power_button_timeout &
		if [ $VCItype != "STD" -a $VCItype != "STD-E" -a $VCItype != "6516" ]; then
			./Power_button_LEDs_beeper.txt
		else
			./User-Interface-Test.STD beeper
		fi
		if [ $? != 0 ]; then
			echo "Beeper/Power-button test either failed or timed-out." >> ../results/Beeper.FAIL
			echo "Beeper/Power-button test either failed or timed-out." >> ../results/burnin-time
			LEDs_or_beeper_fail=TRUE
		else
			echo "Beeper/Power-button test passed." >> ../results/Beeper.PASS
			echo "Beeper/Power-button test passed." >> ../results/burnin-time
		fi
		
		killall -q power_button_timeout >& /dev/null

		if [ $LEDs_or_beeper_fail = TRUE ]; then
			if [ $VCItype != "STD" -a $VCItype != "STD-E" -a $VCItype != "6516" ]; then
				echo -n "13 " >> /tmp/external-failures
			else
				#echo -n "9 " >> /tmp/external-failures
				echo -n "14 " >> /tmp/external-failures
			fi
		fi
	
	
		if [ $VCItype != "STD" -a $VCItype != "STD-E" -a $VCItype != "6516" ]; then
			echo "Starting trigger switch test..."
			echo "Trigger switch test..." >> ../results/burnin-time
			./trigger_timeout &
			./Trigger_Switch_Connector_Test.txt
			if [ $? != 0 ]; then
				echo "Trigger switch test either failed or timed-out." >> ../results/Trigger_switch.FAIL
				echo "Trigger switch test either failed or timed-out." >> ../results/burnin-time
				echo -n "14 " >> /tmp/external-failures
			else
				echo "Trigger switch test passed." >> ../results/Trigger_switch.PASS
				echo "Trigger switch test passed." >> ../results/burnin-time
			fi

			killall -q trigger_timeout >& /dev/null
		fi
		echo "Running Single Pass of HWCheckout"
		echo "Single pass diagnostics..."  >> ../results/burnin-time
		# put httpd to sleep
		#killall -STOP httpd
		# turn radio off to reduce current fluctuations during burnin
		#/usr/sbin/iwpriv eth1 radiooff
		./hwcheckout -l 1
		echo "Single pass diagnostics done"  >> ../results/burnin-time
		sync
		sync
	fi
	
fi	# loopback present

killall -q startcount
killall -q poll_power_button
killall -q power_button_timeout

# turn radio back on to enable wireless comms
#/usr/sbin/iwpriv eth1 radioon
# wake up httpd
#killall -CONT httpd
