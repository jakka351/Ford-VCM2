echo "VCM""START_7f3a91" ; id ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; uname -a ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; cat /proc/version ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; cat /proc/mtd ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; echo SHELL=$0 BASH=$BASH_VERSION ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; for a in busybox base64 md5sum sha256sum sha1sum gzip gunzip tar nc wget tftp ftpput dd cat od xxd uuencode openssl flashcp flash_unlock mount df fw_printenv; do p=$(command -v $a 2>/dev/null); echo "$a=${p:-NO}"; done ; echo "VCM""END_7f3a91=$?="
exit
echo "VCM""START_7f3a91" ; ifconfig 2>/dev/null | head -40 ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; df -h 2>/dev/null ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; nc 2>&1 | head -20 ; echo "VCM""END_7f3a91=$?="
printf 'HELLO_VCM_12345\n' | nc -l -p 9000
echo "VCM""START_7f3a91" ; md5sum /proc/mtd | cut -d' ' -f1 ; echo "VCM""END_7f3a91=$?="
gzip -c /proc/mtd | nc -l -p 9001
exit
echo "VCM""START_7f3a91" ; cat /proc/mtd ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; cat /proc/cmdline ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; cat /proc/partitions ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; uname -a; echo; cat /proc/version ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; mount; echo '--- /proc/mounts ---'; cat /proc/mounts ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; df -h; echo '---'; df ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; ps w 2>/dev/null || ps ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; ifconfig -a ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; netstat -tlnp 2>/dev/null; echo '--- all ---'; netstat -an 2>/dev/null ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; lsmod 2>/dev/null; echo '--- /proc/modules ---'; cat /proc/modules ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; dmesg ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; free 2>/dev/null; echo '--- meminfo ---'; cat /proc/meminfo ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; cat /proc/cpuinfo ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; env; echo '--- set ---'; set ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; echo '--- passwd ---'; cat /etc/passwd 2>/dev/null; echo '--- shadow ---'; cat /etc/shadow 2>/dev/null; echo '--- group ---'; cat /etc/group 2>/dev/null ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; hostname; echo; id; echo; cat /etc/hostname 2>/dev/null ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; echo '=== inittab ==='; cat /etc/inittab 2>/dev/null; echo; echo '=== init.d ==='; ls -la /etc/init.d 2>/dev/null; echo; for f in /etc/init.d/* /etc/rc* /etc/profile; do echo "===== $f ====="; cat "$f" 2>/dev/null; done ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; ls -la / ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; ls -la /etc; echo; ls -laR /etc/vci 2>/dev/null ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; ls -laR /usr/local 2>/dev/null ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; ls -laR /mnt/sd 2>/dev/null ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; echo '=== self-test ==='; find / -name 'self-test*' 2>/dev/null; echo '=== cgi ==='; find / \( -name '*.cgi' -o -path '*cgi-bin*' \) 2>/dev/null; echo '=== httpd ==='; find / -name 'httpd*' 2>/dev/null; echo '=== hwtest ==='; find / -path '*hwtest*' 2>/dev/null ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; echo '=== apps dirs ==='; find / -type d -name 'vci-diags' 2>/dev/null; find / -type d -name 'apps' 2>/dev/null; echo '=== *.sh ==='; find / -name '*.sh' 2>/dev/null ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; echo '=== /etc/vci/config tree ==='; ls -laR /etc/vci/config 2>/dev/null; echo '=== testmode flag? ==='; ls -la /etc/vci/config/testmode 2>/dev/null; echo '=== cat small cfgs ==='; for f in $(find /etc/vci/config -type f 2>/dev/null); do echo "----- $f -----"; (head -c 400 "$f"; echo) 2>/dev/null; done ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; echo '=== mtd11 serialnum (od) ==='; dd if=/dev/mtd11 bs=256 count=1 2>/dev/null | od -c | head -20; echo '=== mtd12 macaddress (od) ==='; dd if=/dev/mtd12 bs=256 count=1 2>/dev/null | od -c | head -20; echo '=== mtd9 linuxvars1 ==='; dd if=/dev/mtd9 bs=512 count=1 2>/dev/null | od -c | head -30; echo '=== mtd10 linuxvars2 ==='; dd if=/dev/mtd10 bs=512 count=1 2>/dev/null | od -c | head -30; echo '=== mtd2 bootvars ==='; dd if=/dev/mtd2 bs=512 count=2 2>/dev/null | od -c | head -40 ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; for f in /etc/version /etc/issue /etc/os-release /usr/local/etc/version /etc/vci/version; do echo "===== $f ====="; cat "$f" 2>/dev/null; done; echo '=== find version-ish ==='; find / \( -iname '*version*' -o -iname '*release*' \) -type f 2>/dev/null | head -40 ; echo "VCM""END_7f3a91=$?="
echo "VCM""START_7f3a91" ; tar 2>&1 | head -40; echo '=== busybox applets ==='; busybox 2>&1 | tail -30 ; echo "VCM""END_7f3a91=$?="
exit
echo "VCM""START_7f3a91" ; md5sum /dev/mtd0 | cut -d' ' -f1 ; echo "VCM""END_7f3a91=$?="
dd if=/dev/mtd0 bs=65536 2>/dev/null | gzip -c | nc -l -p 9100 -w 30
echo "VCM""START_7f3a91" ; md5sum /dev/mtd1 | cut -d' ' -f1 ; echo "VCM""END_7f3a91=$?="
dd if=/dev/mtd1 bs=65536 2>/dev/null | gzip -c | nc -l -p 9101 -w 30
echo "VCM""START_7f3a91" ; md5sum /dev/mtd2 | cut -d' ' -f1 ; echo "VCM""END_7f3a91=$?="
dd if=/dev/mtd2 bs=65536 2>/dev/null | gzip -c | nc -l -p 9102 -w 30
echo "VCM""START_7f3a91" ; md5sum /dev/mtd3 | cut -d' ' -f1 ; echo "VCM""END_7f3a91=$?="
dd if=/dev/mtd3 bs=65536 2>/dev/null | gzip -c | nc -l -p 9103 -w 30
echo "VCM""START_7f3a91" ; md5sum /dev/mtd4 | cut -d' ' -f1 ; echo "VCM""END_7f3a91=$?="
dd if=/dev/mtd4 bs=65536 2>/dev/null | gzip -c | nc -l -p 9104 -w 30
echo "VCM""START_7f3a91" ; md5sum /dev/mtd5 | cut -d' ' -f1 ; echo "VCM""END_7f3a91=$?="
dd if=/dev/mtd5 bs=65536 2>/dev/null | gzip -c | nc -l -p 9105 -w 30
echo "VCM""START_7f3a91" ; md5sum /dev/mtd6 | cut -d' ' -f1 ; echo "VCM""END_7f3a91=$?="
dd if=/dev/mtd6 bs=65536 2>/dev/null | gzip -c | nc -l -p 9106 -w 30
echo "VCM""START_7f3a91" ; md5sum /dev/mtd7 | cut -d' ' -f1 ; echo "VCM""END_7f3a91=$?="
dd if=/dev/mtd7 bs=65536 2>/dev/null | gzip -c | nc -l -p 9107 -w 30
echo "VCM""START_7f3a91" ; md5sum /dev/mtd8 | cut -d' ' -f1 ; echo "VCM""END_7f3a91=$?="
dd if=/dev/mtd8 bs=65536 2>/dev/null | gzip -c | nc -l -p 9108 -w 30
echo "VCM""START_7f3a91" ; md5sum /dev/mtd9 | cut -d' ' -f1 ; echo "VCM""END_7f3a91=$?="
dd if=/dev/mtd9 bs=65536 2>/dev/null | gzip -c | nc -l -p 9109 -w 30
echo "VCM""START_7f3a91" ; md5sum /dev/mtd10 | cut -d' ' -f1 ; echo "VCM""END_7f3a91=$?="
dd if=/dev/mtd10 bs=65536 2>/dev/null | gzip -c | nc -l -p 9110 -w 30
echo "VCM""START_7f3a91" ; md5sum /dev/mtd11 | cut -d' ' -f1 ; echo "VCM""END_7f3a91=$?="
dd if=/dev/mtd11 bs=65536 2>/dev/null | gzip -c | nc -l -p 9111 -w 30
echo "VCM""START_7f3a91" ; md5sum /dev/mtd12 | cut -d' ' -f1 ; echo "VCM""END_7f3a91=$?="
dd if=/dev/mtd12 bs=65536 2>/dev/null | gzip -c | nc -l -p 9112 -w 30
exit
