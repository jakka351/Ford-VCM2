# System-wide .bashrc file for interactive bash(1) shells.

shopt -s checkwinsize

export PATH=/usr/local/j9/bin:$PATH
